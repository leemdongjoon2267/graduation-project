package comment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import board.BoardVO;

public class CommentDAO {
	private Connection conn;	// 데이터베이스에 접근하게 해주는 하나의 객체
	private ResultSet rs;		// 정보를 담을 수 있는 객체

	public CommentDAO() {
		try {
			/*
			 * String driver="org.mariadb.jdbc.Driver"; String
			 * url="jdbc:mariadb://183.111.199.216:3306/ljs2267"; String dbId="ljs2267";
			 * String dbPw="ehdwns2020@@!"; Class.forName(driver); conn =
			 * DriverManager.getConnection(url, dbId, dbPw);
			 * System.out.println("MariaDB와 연결되었습니다.");
			 */

			String driver = "com.mysql.cj.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/festival?useUnicode=true&serverTimezone=Asia/Seoul&jdbcCompliantTruncation=false";
			String dbId = "festival";
			String dbPw = "ehgus12";
			Class.forName(driver);
			conn = DriverManager.getConnection(url, dbId, dbPw);
			System.out.println("MySql과 연결되었습니다.");

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("MySql과 연결에 실패했습니다.");
		}
	}
	
	// 현재 서버 시간 가져오기
	public String getDate() {	
		String SQL = "select DATE_FORMAT(now(), '%Y-%m-%d %H:%i:%s');";	// 현재 시간을 가져오는 mysql 쿼리문
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL); // sql문장을 실행 준비 단계로
			rs=pstmt.executeQuery();	// 실행결과 가져오기
			if(rs.next()) {
				return rs.getString(1);	// 현재 날짜 반환
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return "";	// 데이터베이스 오류
	}
	
	public int getNext() {
		String SQL = "SELECT commentID from COMMENT order by commentID DESC"; // 마지막 게시물 반환
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; // 첫 번째 게시물인 경우
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;	// 데이터베이스 오류
	}
	
	// 댓글 작성
	public int write(String commentContent, String userID, int boardNo) {
		String SQL = "insert into COMMENT VALUES (?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setInt(2, boardNo);
			pstmt.setString(3, userID);
			pstmt.setString(4, commentContent);
			pstmt.setString(5, getDate());
			pstmt.setInt(6, 1);
			return pstmt.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}

	// 해당 글에 작성된 댓글 불러오기
	public ArrayList<CommentVO> getList(int boardNo) {
		// 마지막 게시물 반환, 삭제가 되지 않은 글만 가져온다.
		String SQL="SELECT * from comment where boardNo = ? AND commentAvailable = 1 order by boardNo desc limit 10"; 
		ArrayList<CommentVO> list = new ArrayList<CommentVO>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, boardNo);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				CommentVO commentVO = new CommentVO();
				commentVO.setCommentID(rs.getInt(1));
				commentVO.setBoardNo(rs.getInt(2));
				commentVO.setUserID(rs.getString(3));
				commentVO.setCommentContent(rs.getString(4));
				commentVO.setCommentDate(rs.getString(5));
				commentVO.setCommentAvailable(rs.getInt(6));
				list.add(commentVO);
			}			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return list;//댓글 리스트 반환
	}
	
	// 하나의 댓글 내용을 불러오는 함수
	public CommentVO getComment(int commentID) {
		String SQL="SELECT * from comment where commentID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, commentID);
			rs=pstmt.executeQuery();	// select
			if(rs.next()) {	// 결과가 있다면
				CommentVO commentVO = new CommentVO();
				commentVO.setCommentID(rs.getInt(1));
				commentVO.setBoardNo(rs.getInt(2));
				commentVO.setUserID(rs.getString(3));
				commentVO.setCommentContent(rs.getString(4));
				commentVO.setCommentDate(rs.getString(5));
				commentVO.setCommentAvailable(rs.getInt(6));
				return commentVO;
			}			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	// 댓글 수정
	public int update(int boardNo, int commentID, String commentContent ) {
		// 특정한 아이디에 해당하는 제목과 내용을 바꿔준다.
		String SQL="update comment set commentContent = ? where boardNo = ? and commentID = ?"; 
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, commentContent); // SQL문 물음표의 순서
			pstmt.setInt(2, boardNo);
			pstmt.setInt(3, commentID);
			return pstmt.executeUpdate(); // insert,delete,update			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
	
	// 댓글 삭제
	public int delete(int commentID) {
		String SQL = "update COMMENT set commentAvailable = 0 where commentID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, commentID);
			return pstmt.executeUpdate();			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
	
}
