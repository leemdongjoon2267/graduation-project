package board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BoardDAO {
	
	private Connection conn;	// 데이터베이스에 접근하게 해주는 하나의 객체
	private ResultSet rs;	// 정보를 담을 수 있는 객체
	
	public BoardDAO() {	
		try {
			/*
			 * String driver="org.mariadb.jdbc.Driver"; String
			 * url="jdbc:mariadb://183.111.199.216:3306/ljs2267"; String dbId="ljs2267";
			 * String dbPw="ehdwns2020@@!"; Class.forName(driver); conn =
			 * DriverManager.getConnection(url, dbId, dbPw);
			 * System.out.println("MariaDB와 연결되었습니다.");
			 */

			String driver = "com.mysql.cj.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/festival?useUnicode=true&serverTimezone=Asia/Seoul&jdbcCompliantTruncation=false";
			String dbId = "festival";
			String dbPw = "ehgus12";
			Class.forName(driver);
			conn = DriverManager.getConnection(url, dbId, dbPw);
			System.out.println("MySql과 연결되었습니다.");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// 현재 서버 시간 가져오기
	public String getDate() {
		String SQL = "select now()";	// 현재 시간을 가져오는 mysql문장
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return "";	// 데이터베이스 오류
	}
	
	// 마지막 게시물 반환
	public int getNext() {
		String SQL="SELECT boardNo from festival.board order by boardNo DESC";	
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; // 첫 번째 게시물인 경우
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;	// 데이터베이스 오류
	}
	
	// 게시글 작성
	public int write(String boardTitle, String userID, String boardContent, int boardCount, int LikeCount) {
		String SQL="INSERT INTO festival.board VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());	// 게시글 번호
			pstmt.setString(2, userID);	// 아이디
			pstmt.setString(3, boardTitle);	// 제목
			pstmt.setString(4, boardContent);	// 내용
			pstmt.setString(5, getDate());	// 날짜
			pstmt.setInt(6, 1);	// 삭제된 경우가 아니기 때문에 1을 넣어줌
			pstmt.setInt(7, boardCount);
			pstmt.setInt(8, LikeCount);
			return pstmt.executeUpdate();			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;	// 데이터베이스 오류
	}
	
	// 데이터베이스에서 글의 목록을 가져오는 소스코드 작성
	public ArrayList<BoardVO> getList(int pageNumber){	//	특정한 리스트를 받아서 반환
		// 마지막 게시물 반환, 삭제가 되지 않은 글만 가져온다.
		String SQL="SELECT * from festival.board where boardNo < ? AND boardAvailable = 1 order by boardNo desc limit 10";
		ArrayList<BoardVO> list = new ArrayList<BoardVO>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext()-(pageNumber-1)*10);	// 물음표에 들어갈 내용
			rs=pstmt.executeQuery();
			while(rs.next()) {
				BoardVO boardVO = new BoardVO();
				boardVO.setBoardNo(rs.getInt(1));
				boardVO.setUserID(rs.getString(2));
				boardVO.setBoardTitle(rs.getString(3));
				boardVO.setBoardContent(rs.getString(4));
				boardVO.setCreateDate(rs.getString(5));
				boardVO.setBoardAvailable(rs.getInt(6));
				boardVO.setBoardCount(rs.getInt(7));
				boardVO.setLikeCount(rs.getInt(8));
				list.add(boardVO);	// list에 해당 인스턴스를 담는다.
			}			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return list;	// 게시글 리스트 반환
	}
	
	public int getCount() {
		String SQL = "select count(*) from festival.board";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1);
			}			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	// 페이지 처리를 위한 함수
	public boolean nextPage(int pageNumber) {
		String SQL="SELECT * from festival.board where boardNo < ? AND boardAvailable =1";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext()-(pageNumber-1)*10);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return true;	// 다음 페이지로 넘어갈 수 있음
			}			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	// 하나의 글 내용을 불러오는 함수
	public BoardVO getBoard(int boardNo) {
		String SQL = "SELECT * from festival.board where boardNo = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, boardNo);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				BoardVO boardVO = new BoardVO();
				boardVO.setBoardNo(rs.getInt(1));
				boardVO.setUserID(rs.getString(2));
				boardVO.setBoardTitle(rs.getString(3));
				boardVO.setBoardContent(rs.getString(4));
				boardVO.setCreateDate(rs.getString(5));
				boardVO.setBoardAvailable(rs.getInt(6));
				int boardCount = rs.getInt(7);
				boardVO.setBoardCount(boardCount);
				boardCount++;
				countUpdate(boardCount,boardNo);
				boardVO.setLikeCount(rs.getInt(8));
				return boardVO;	// 6개의 항목을 boardVO인스턴스에 넣어 반환한다.
			}			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public int countUpdate(int boardCount, int boardNo) {
		String SQL = "update festival.board set boardCount = ? where boardNo = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, boardCount);
			pstmt.setInt(2, boardNo);
			return pstmt.executeUpdate();			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;	// 데이터베이스 오류
	}
	
	
	//특정한 아이디에 해당하는 제목과 내용을 바꿔줌
	public int update(int boardNo, String boardTitle,String boardContent ) {
		String SQL="update festival.board set boardTitle = ?, boardContent = ? where boardNo = ?"; 
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setString(1, boardTitle);
			pstmt.setString(2, boardContent);
			pstmt.setInt(3, boardNo);
			return pstmt.executeUpdate();			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;	// 데이터베이스 오류
	}
	
	public int delete(int boardNo) {
		String SQL = "update festival.board set boardAvailable = 0 where boardNo = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, boardNo);
			return pstmt.executeUpdate();			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;	// 데이터베이스 오류
	}
	
	public int like(int boardNo) {
		String SQL = "update festival.board set likeCount = likeCount + 1 where boardNo = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, boardNo);
			return pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		} 
		return -1;
	}
	
	// 게시글 조회
	public ArrayList<BoardVO> getSearch(String searchField, String searchText){
	      ArrayList<BoardVO> list = new ArrayList<BoardVO>();
	      String SQL ="select * from festival.board WHERE "+ searchField.trim();
	      try {
	            if(searchText != null && !searchText.equals("") ){
	                SQL +=" LIKE '%"+searchText.trim()+"%' order by boardNo desc limit 10";
	            }
	            PreparedStatement pstmt=conn.prepareStatement(SQL);
				rs=pstmt.executeQuery();
	         while(rs.next()) {
	        	BoardVO boardVO = new BoardVO();
	        	boardVO.setBoardNo(rs.getInt(1));
	        	boardVO.setUserID(rs.getString(2));
	        	boardVO.setBoardTitle(rs.getString(3));
	        	boardVO.setBoardContent(rs.getString(4));
	        	boardVO.setCreateDate(rs.getString(5));
	        	boardVO.setBoardAvailable(rs.getInt(6));
	        	boardVO.setBoardCount(rs.getInt(7));
	        	boardVO.setLikeCount(rs.getInt(8));
	            list.add(boardVO);
	         }         
	      } catch(Exception e) {
	         e.printStackTrace();
	      }
	      return list;	//게시글 리스트 반환
	   }
}