package likey;

public class LikeyVO {
	private String userID;
	private int boardNo;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public int getboardNo() {
		return boardNo;
	}
	public void setboardNo(int boardNo) {
		this.boardNo = boardNo;
	}
}
