document.getElementById("seoul").addEventListener("click", function() {
        
        alert("서울 지역을 클릭하셨습니다.");
    });

document.getElementById("busan").addEventListener("click", function() {
        
        alert("부산 지역을 클릭하셨습니다.");
    });

document.getElementById("daegu").addEventListener("click", function() {
        
        alert("대구 지역을 클릭하셨습니다.");
    });

document.getElementById("incheon").addEventListener("click", function() {
        
        alert("인천 지역을 클릭하셨습니다.");
    });

document.getElementById("gwangju").addEventListener("click", function() {
        
        alert("광주  지역을 클릭하셨습니다.");
    });

document.getElementById("ulsan").addEventListener("click", function() {
        
        alert("울산 지역을 클릭하셨습니다.");
    });

document.getElementById("gyeonggi").addEventListener("click", function() {
        
        alert("경기 지역을 클릭하셨습니다.");
    });
document.getElementById("gangwon").addEventListener("click", function() {
        
        alert("강원 지역을 클릭하셨습니다.");
    });

document.getElementById("chungbuk").addEventListener("click", function() {
        
        alert("충북 지역을 클릭하셨습니다.");
    });

document.getElementById("chungnam").addEventListener("click", function() {
        
        alert("충남 지역을 클릭하셨습니다.");
    });

document.getElementById("gyeongbuk").addEventListener("click", function() {
        
        alert("경북 지역을 클릭하셨습니다.");
    });

document.getElementById("gyeongnam").addEventListener("click", function() {
        
        alert("경남 지역을 클릭하셨습니다.");
    });

document.getElementById("jeonbuk").addEventListener("click", function() {
        
        alert("전북 지역을 클릭하셨습니다.");
    });

document.getElementById("jeonnam").addEventListener("click", function() {
        
        alert("전남 지역을 클릭하셨습니다.");
    });

document.getElementById("jeju").addEventListener("click", function() {
        
        alert("제주 지역을 클릭하셨습니다.");
    });

document.getElementById("sejong").addEventListener("click", function() {
        
        alert("세종 지역을 클릭하셨습니다.");
    });

