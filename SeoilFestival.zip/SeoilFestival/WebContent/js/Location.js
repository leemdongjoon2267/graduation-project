var mainRegions = document.getElementsByClassName("main-region");
        for (var i = 0; i < mainRegions.length; i++) {
            mainRegions[i].addEventListener("click", function() {
                var subRegions = this.nextElementSibling;
                if (subRegions.style.display === "none") {
                    subRegions.style.display = "block";
                } else {
                    subRegions.style.display = "none";
                }
            });
        }